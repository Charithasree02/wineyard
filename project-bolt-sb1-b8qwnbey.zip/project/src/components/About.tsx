import React from 'react';

export default function About() {
  return (
    <div className="pt-20 pb-16 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-400">
            About Wine Yard
          </h2>
          <p className="text-gray-300 max-w-3xl mx-auto">
            Wine Yard is revolutionizing how wine enthusiasts connect, share, and monetize their passion.
            Our platform brings together creators and consumers in a vibrant community centered around wine culture.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1567072379-fde31b29e0a7?auto=format&fit=crop&q=80"
              alt="Wine community"
              className="rounded-lg shadow-xl"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent rounded-lg"></div>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-semibold mb-2">Our Mission</h3>
              <p className="text-gray-300">
                To create the most engaging and rewarding platform for wine enthusiasts to share their knowledge,
                experiences, and passion while building meaningful connections.
              </p>
            </div>

            <div>
              <h3 className="text-2xl font-semibold mb-2">Why Choose Wine Yard?</h3>
              <ul className="space-y-3 text-gray-300">
                <li>✨ Dedicated wine-focused community</li>
                <li>💰 Monetization opportunities for creators</li>
                <li>🌟 High-quality, curated content</li>
                <li>🤝 Connect with fellow wine enthusiasts</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}